use anwars;
CREATE TABLE LocationTrace (
  UserID varchar(50),
  Latitude DOUBLE,
  Longitude DOUBLE,
  Altitude DOUBLE,
  TimeInserted timestamp
);